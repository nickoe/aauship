Modify the 65th line to the correct python-executable path.

Invoke the function: python('functionname-py', 'parameters in string(!)')

Example: pyton('sqr.py', '2')