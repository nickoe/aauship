1. Open ASV_pathplot.mdl
2. Click Start Engines
3. ignore the errors...
4. Click again
5. Click again
6. Adjust the Left/Right sliders to add propulsion
7. The Gauge on the left shows the current orientation of the ship
8. A new figure is opened that shows the path


Aim: The model can be compiled and can be interfaced with another program. The running python program can control the inputs of the simulation, and can receive simulated sensor feedback data in real- or accelerated-time.